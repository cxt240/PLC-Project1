# PLC-Project1

@authors: Kavan Mally, Chris Tsuei, Andrew Su

We are not implementing multiple assigns in this interpreter.

Interpreter is the file containing the compiler. To call the interpreter, given a filename (filename.txt).

(instr (parser "filename.txt") '(() ()))
